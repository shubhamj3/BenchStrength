package com.brillio.benchtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BenchTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
